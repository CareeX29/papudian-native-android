# Source analysis notes

- APK assets include `assets/www/index.html`, `assets/www/config.json`, and `assets/www/splash.png`.
- The splash configuration sets `splashBgColor` to `#0F1318`, loader color `#00E5CC`, icon size 130, loader size 50, splash duration 2 seconds, and fade duration 400 ms.
- The original HTML stores song data in inline JavaScript arrays. It uses bracketed note tokens before sung syllables; underscores mark connected note groups.
- The provided PDF references show music notation and lyrics together, useful for verifying the original notation.
- Extracted song data count: 161 Pa'Pudian + 205 Penanian Masallo' = 366 total.
- The native preview attempts to render note labels above lyric segments. Exact spacing/beam behavior is not yet verified.
