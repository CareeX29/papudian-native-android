package com.example.papudiannative

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray

private val Paper = Color(0xFFFAF9F6)
private val Ink = Color(0xFF33363A)
private val Muted = Color(0xFF8A8D91)
private val Line = Color(0xFFE8E6E0)
private val Accent = Color(0xFF6F8F86)
private val Chip = Color(0xFFEEF2F0)
private val SplashBackground = Color(0xFF0F1318)
private val SplashLoader = Color(0xFF00E5CC)

data class Song(
    val number: String, val title: String, val key: String, val tempo: String,
    val reference: String, val notes: String, val lyrics: String
)
data class SongBook(val name: String, val songs: List<Song>)
private data class LyricNote(val value: String, val beam: Boolean)
private data class LyricSegment(val notes: List<LyricNote>, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val books = loadBooks()
        window.statusBarColor = android.graphics.Color.rgb(15, 19, 24)
        window.navigationBarColor = android.graphics.Color.rgb(250, 249, 246)
        setContent {
            MaterialTheme {
                var showSplash by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) { delay(2000); showSplash = false }
                Crossfade(targetState = showSplash, animationSpec = tween(400), label = "splash-transition") { splash ->
                    if (splash) NativeSplash() else SongbookApp(books)
                }
            }
        }
    }

    private fun loadBooks(): List<SongBook> {
        val raw = assets.open("songs.json").bufferedReader().use { it.readText() }
        val root = JSONArray(raw)
        return (0 until root.length()).map { i ->
            val book = root.getJSONObject(i)
            val arr = book.getJSONArray("songs")
            val songs = (0 until arr.length()).map { j ->
                val s = arr.getJSONObject(j)
                Song(
                    number = s.optString("nomor"), title = s.optString("judul"),
                    key = s.optString("nada_dasar"), tempo = s.optString("tempo"),
                    reference = s.optString("rujukan"), notes = s.optString("not"), lyrics = s.optString("lirik")
                )
            }
            SongBook(book.getString("name"), songs)
        }
    }
}

@Composable
private fun NativeSplash() {
    Column(
        modifier = Modifier.fillMaxSize().background(SplashBackground),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(R.drawable.splash),
            contentDescription = "Pa'Pudian",
            modifier = Modifier.size(130.dp).clip(RoundedCornerShape(25.dp))
        )
        Spacer(Modifier.height(10.dp))
        CircularProgressIndicator(
            modifier = Modifier.size(50.dp), color = SplashLoader,
            strokeWidth = 4.dp, trackColor = SplashLoader.copy(alpha = 0.18f)
        )
    }
}

@Composable
private fun SongbookApp(books: List<SongBook>) {
    var selectedBook by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var selectedSong by remember { mutableStateOf<Song?>(null) }
    BackHandler(enabled = selectedSong != null) { selectedSong = null }

    Column(Modifier.fillMaxSize().background(Paper)) {
        Column(Modifier.fillMaxWidth().background(Paper).padding(horizontal = 20.dp, vertical = 14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                books.forEachIndexed { index, book ->
                    Surface(
                        color = if (selectedBook == index) Accent else Chip,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.clickable {
                            selectedBook = index; query = ""; selectedSong = null
                        }
                    ) {
                        Text(book.name, color = if (selectedBook == index) Color.White else Ink,
                            fontSize = 13.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(if (selectedSong == null) books[selectedBook].name else "Lagu ${selectedSong!!.number}",
                color = Ink, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
            Text("Buku nyanyian rohani", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            if (selectedSong == null) {
                Surface(color = Color.White, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Line)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⌕", color = Muted, fontSize = 19.sp)
                        Spacer(Modifier.width(10.dp))
                        BasicTextField(value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp),
                            decorationBox = { inner ->
                                if (query.isEmpty()) Text("Cari judul atau nomor lagu", color = Muted, fontSize = 15.sp)
                                inner()
                            }, modifier = Modifier.fillMaxWidth())
                    }
                }
            } else {
                TextButton(onClick = { selectedSong = null }) { Text("←  Kembali", color = Accent) }
            }
        }
        if (selectedSong == null) {
            val q = query.trim()
            val filtered = books[selectedBook].songs.filter {
                q.isEmpty() || it.number.startsWith(q, ignoreCase = true) || it.title.contains(q, ignoreCase = true)
            }
            LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 28.dp)) {
                if (filtered.isEmpty()) item { Text("Lagu tidak ditemukan. Coba judul atau nomor lain.", color = Muted, modifier = Modifier.padding(16.dp)) }
                items(filtered) { song ->
                    Column(Modifier.fillMaxWidth().clickable { selectedSong = song }.padding(vertical = 15.dp)) {
                        Row {
                            Text(song.number, color = Accent, fontSize = 14.sp, modifier = Modifier.width(42.dp))
                            Text(song.title, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        }
                        Spacer(Modifier.height(14.dp)); HorizontalDivider(color = Line)
                    }
                }
            }
        } else {
            val song = selectedSong!!
            LazyColumn(contentPadding = PaddingValues(horizontal = 22.dp, vertical = 8.dp)) {
                item {
                    Text("${books[selectedBook].name} · No. ${song.number}", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(song.title, color = Ink, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    if (song.reference.isNotBlank()) Text(song.reference, color = Accent, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (song.key.isNotBlank()) MetaChip(song.key)
                        if (song.tempo.isNotBlank()) MetaChip(if (song.tempo.contains("/")) "Birama: ${song.tempo}" else "Tempo: ${song.tempo}")
                    }
                    if (song.notes.isNotBlank()) Text(song.notes, color = Muted, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.height(20.dp))
                    LyricsView(song.lyrics)
                    Spacer(Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
private fun LyricsView(lyrics: String) {
    val verses = lyrics.trim().split(Regex("\\n\\s*\\n"))
    Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        verses.forEach { verse ->
            val lines = verse.split('\n')
            if (!verse.contains('[')) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    lines.forEach { Text(it, color = Ink, fontSize = 16.sp, lineHeight = 28.sp) }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    lines.forEach { line ->
                        if (!line.contains('[')) {
                            Text(line, color = Ink, fontSize = 16.sp, lineHeight = 28.sp)
                        } else {
                            Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.Bottom) {
                                parseLyricLine(line).forEach { segment ->
                                    Column(horizontalAlignment = Alignment.Start) {
                                        Row(Modifier.heightIn(min = 22.dp), verticalAlignment = Alignment.Bottom) {
                                            segment.notes.forEachIndexed { idx, note ->
                                                if (idx > 0) Spacer(Modifier.width(2.dp))
                                                Text(note.value, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                                    textDecoration = if (note.beam) TextDecoration.Underline else TextDecoration.None)
                                            }
                                        }
                                        Text(segment.text.ifEmpty { " " }, color = Ink, fontSize = 16.sp, lineHeight = 27.sp,
                                            softWrap = false)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun parseLyricLine(line: String): List<LyricSegment> {
    val parts = Regex("(\\[[^\\]]*\\])").splitWithDelimitersCompat(line)
    val segments = mutableListOf<LyricSegment>()
    var chord = ""
    parts.forEach { part ->
        if (part.startsWith("[") && part.endsWith("]")) {
            if (chord.isNotEmpty()) segments += LyricSegment(parseNotes(chord), "")
            chord = part.substring(1, part.length - 1)
        } else if (part.isNotEmpty()) {
            segments += LyricSegment(parseNotes(chord), part)
            chord = ""
        }
    }
    if (chord.isNotEmpty()) segments += LyricSegment(parseNotes(chord), "")
    return segments
}

private fun Regex.splitWithDelimitersCompat(input: String): List<String> {
    val out = mutableListOf<String>()
    var last = 0
    findAll(input).forEach { match ->
        if (match.range.first > last) out += input.substring(last, match.range.first)
        out += match.value
        last = match.range.last + 1
    }
    if (last < input.length) out += input.substring(last)
    return out
}

private fun parseNotes(raw: String): List<LyricNote> {
    var inBeam = false
    return raw.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.map { token ->
        val starts = token.length > 1 && token.startsWith("_")
        val ends = token.length > 1 && token.endsWith("_")
        val beam = inBeam || starts
        val cleaned = token.removePrefix("_").removeSuffix("_")
        if (ends) inBeam = false else if (starts) inBeam = true
        LyricNote(cleaned, beam)
    }
}

@Composable
private fun MetaChip(text: String) {
    Surface(color = Chip, shape = RoundedCornerShape(20.dp)) {
        Text(text, color = Ink, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
    }
}
