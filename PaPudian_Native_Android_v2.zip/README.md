# Pa'Pudian & Penanian Masallo' — native Android port preview

This is a Kotlin + Jetpack Compose source-project scaffold based on the supplied APK and two reference PDFs.

## Included
- 366 song entries extracted from the supplied APK (161 Pa'Pudian + 205 Penanian Masallo').
- Original splash image (`splash.png`) extracted from `assets/www/splash.png`.
- Compose splash screen using the APK configuration values: dark `#0F1318` background, 130dp logo, cyan `#00E5CC` circular loader, approximately 2-second display and 400ms crossfade.
- Native book selection, title/number search, song details, metadata, and lyrics with note labels above lyric segments.
- Reference PDFs in `reference-pdfs/`; these are project references and are not copied into the installed app.

## Build
Open this folder in Android Studio with Android SDK Platform 35 installed, let Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important status
This is a source scaffold, not a verified APK. It has not been compiled or tested in Android Studio in this environment. The lyric-note renderer is a first native approximation of the original web renderer; visual comparison and adjustments are still needed for spacing, beams, and unusual notation cases. The PDFs are references for checking lyric text and musical notation.
